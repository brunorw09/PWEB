# FechaConta — Projeto Final PWEB

Aplicação web de gestão financeira pessoal com **2 telas**:

1. **Login** (`index.html`): tela principal de entrada, com validação dos campos, que leva para a tela de transações.
2. **Transações** (`nova-transacao.html`): CRUD completo de receitas e despesas (cadastrar, listar, pesquisar, alterar e excluir), com saldo calculado a partir dos dados salvos.

**Persistência:** banco de dados local do navegador **IndexedDB** (opção do item 8 do enunciado). Não precisa de servidor, conta ou internet.

## Estrutura

```
ProjetoFinal/
├── index.html                  # Só redireciona para login/index.html (útil no GitHub Pages)
├── login/
│   ├── index.html              # Tela de login (tela principal de entrada)
│   ├── style.css
│   └── script.js
└── nova-transacao/
    ├── nova-transacao.html     # Tela de CRUD de transações
    ├── style2.css
    ├── banco.js                # Conexão e operações no IndexedDB (listar, adicionar, atualizar, excluir)
    ├── erros.js                # Tradução das mensagens de erro do IndexedDB
    └── script2.js              # Lógica da tela (formulário, validação, lista, pesquisa)
```

## Modelo de dados (IndexedDB)

Banco `FechaContaDB` › object store `transacoes` (chave `id` gerada automaticamente, índices em `data` e `tipo`):

```
id              number    1
descricao       string    "Mercado Central"
valor           number    150.9
tipo            string    "despesa" | "receita"
categoria       string    "Alimentação"
data            string    "2026-11-06"
recorrencia     string    "Nenhuma" | "Diário" | "Semanal" | "Mensal" | "Anual"
formaPagamento  string    "cartao" | "pix" | "dinheiro"
criadoEm        string    data/hora ISO
atualizadoEm    string    data/hora ISO (quando editado)
```

## Como consultar o banco diretamente

**Pela tela (DevTools):** abra a tela de transações, aperte **F12** › aba **Application** (no Firefox: **Armazenamento**) › **IndexedDB** › **FechaContaDB** › **transacoes**. Clique com o botão direito em `transacoes` › *Refresh* para ver as mudanças mais recentes.

**Pelo Console (F12 › Console)**, com a tela de transações aberta:

```js
// Todas as transações, em forma de tabela
Banco.listar().then(console.table)

// Uma transação pelo id
Banco.buscar(1).then(console.log)

// Filtrar: só despesas acima de R$ 100
Banco.listar().then(l => console.table(l.filter(t => t.tipo === 'despesa' && t.valor > 100)))

// Saldo total
Banco.listar().then(l => l.reduce((s, t) => t.tipo === 'receita' ? s + t.valor : s - t.valor, 0))

// Consulta por índice (sem o objeto Banco): transações de um dia
indexedDB.open('FechaContaDB').onsuccess = e =>
  e.target.result.transaction('transacoes').objectStore('transacoes')
    .index('data').getAll('2026-11-06').onsuccess = r => console.table(r.target.result)
```

**Apagar tudo (recomeçar do zero):** F12 › Application › IndexedDB › FechaContaDB › botão **Delete database**.

## Como executar

Basta abrir o `login/index.html` (ou o `index.html` da raiz) no navegador, com dois cliques. Também funciona com a extensão *Live Server* do VS Code.

> Os dados ficam salvos **no navegador de quem usa**: outro computador ou outro navegador começa com a lista vazia, e limpar os dados de navegação apaga as transações.

## Hospedagem (GitHub Pages)

1. No repositório PWEB no GitHub: **Settings › Pages › Source: Deploy from a branch** › branch `main`, pasta `/ (root)` › Save.
2. O site fica em `https://SEU-USUARIO.github.io/PWEB/ProjetoFinal/` (o `index.html` da raiz leva ao login).

## Requisitos atendidos

| Critério | Onde |
|---|---|
| Tela principal de entrada | `login/index.html` |
| CRUD com pesquisa | `nova-transacao/nova-transacao.html` + `script2.js` |
| Persistência | IndexedDB (`nova-transacao/banco.js`) |
| Validação de entrada | Login: e-mail e senha obrigatórios (HTML). Transações: valor > 0, descrição, categoria e data válida |
| Tratamento de erros | `nova-transacao/erros.js` traduz os erros do IndexedDB; `try/catch` em todas as operações |
| Segurança | Texto digitado é escapado antes de virar HTML (evita XSS) |
| Responsividade | Layout mobile-first, max-width 480px, media queries para telas pequenas |

## Integrantes

- Allan Batista dos Santos
- Bruno Rocha Wendland
- Murillo Alves Lourenço
