// Visualizar senha
const togglePassword = document.getElementById('toggle-password');
const passwordInput = document.getElementById('password');

togglePassword.addEventListener('click', function () {
    // Alterna o tipo do input entre 'password' e 'text'
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    
    // Alterna o ícone (olho aberto / olho fechado)
    this.classList.toggle('fa-eye');
    this.classList.toggle('fa-eye-slash');
});