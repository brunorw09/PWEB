// =====================================================================
// TELA DE TRANSAÇÕES (nova-transacao.html) — CRUD no IndexedDB
// Substitui a simulação anterior: agora tudo é salvo no banco local.
// ---------------------------------------------------------------------
// Depende de: banco.js (objeto Banco, com as operações no IndexedDB) e
// erros.js (função traduzirErro), carregados antes deste arquivo no HTML.
// A estrutura dos dados está descrita no começo de banco.js.
// =====================================================================

// ====== CONSTANTES ======
const COR_DESPESA = '#ef4444';
const COR_RECEITA = '#10b981';
const COR_VAZIO = '#cbd5e1';
const VALOR_MAXIMO = 999999999.99;
const NOMES_FORMA = { cartao: 'Cartão', pix: 'PIX', dinheiro: 'Dinheiro' };
const RECORRENCIAS = ['Nenhuma', 'Diário', 'Semanal', 'Mensal', 'Anual'];

// ====== ELEMENTOS DA TELA ======
const form = document.getElementById('transaction-form');
const tabDespesa = document.getElementById('tab-despesa');
const tabReceita = document.getElementById('tab-receita');
const valueInput = document.getElementById('valor-input');
const currencySpan = document.querySelector('.currency');
const descInput = document.getElementById('desc-input');
const categoriaInput = document.getElementById('categoria-select');
const dataInput = document.getElementById('data-input');
const recorrenciaInput = document.getElementById('recorrencia-select');
const paymentCards = document.querySelectorAll('.payment-card');
const impactValue = document.getElementById('impact-value');
const impactSub = document.getElementById('impact-sub');
const btnSave = document.getElementById('btn-save');
const btnSaveText = document.getElementById('btn-save-text');
const btnCancel = document.getElementById('btn-cancel');
const formTitle = document.getElementById('form-title');
const btnBack = document.getElementById('btn-back');
const appContent = document.getElementById('app-content');
const searchInput = document.getElementById('search');
const chips = document.querySelectorAll('.chip');
const lista = document.getElementById('lista-transacoes');
const listaStatus = document.getElementById('lista-status');
const contador = document.getElementById('contador');
const toastEl = document.getElementById('toast');

// ====== ESTADO DA TELA ======
let transacoes = [];        // cópia na memória do que está no banco
let tipoAtual = 'despesa';  // aba selecionada
let idEmEdicao = null;      // null = cadastrando | número = editando esse id
let filtroTipo = 'todas';

// =====================================================================
// 1. BOTÃO DE VOLTAR
// =====================================================================
// Se estiver editando, cancela a edição; se não, volta para o login
btnBack.addEventListener('click', () => {
    if (idEmEdicao) {
        limparFormulario();
    } else {
        window.location.href = '../login/index.html';
    }
});

// =====================================================================
// 2. FUNÇÕES DE FORMATAÇÃO
// =====================================================================
function formatarMoeda(valor) {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// "1.234,56" -> 1234.56
function lerValorDigitado() {
    const numero = Number(valueInput.value.replace(/\./g, '').replace(',', '.'));
    return Number.isFinite(numero) ? numero : 0;
}

// 1234.56 -> "1.234,56"
function formatarNumero(valor) {
    return valor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// "2026-11-06" -> "06/11/2026"
function formatarData(dataISO) {
    const [ano, mes, dia] = dataISO.split('-');
    return `${dia}/${mes}/${ano}`;
}

// Data de hoje no formato do <input type="date"> (respeitando o fuso local)
function hojeISO() {
    const d = new Date();
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 10);
}

// Evita que um texto digitado pelo usuário vire HTML (proteção contra XSS)
function escaparHTML(texto) {
    const div = document.createElement('div');
    div.textContent = texto;
    return div.innerHTML;
}

// =====================================================================
// 3. COMPORTAMENTO DO FORMULÁRIO (interface)
// =====================================================================

// Pinta o valor de vermelho/verde (ou cinza quando está zerado)
function atualizarCorValor() {
    const temValor = lerValorDigitado() > 0;
    const cor = !temValor ? COR_VAZIO : (tipoAtual === 'despesa' ? COR_DESPESA : COR_RECEITA);
    valueInput.style.color = cor;
    currencySpan.style.color = cor;
}

// Alternância entre Despesa e Receita
function setTransactionType(tipo) {
    tipoAtual = tipo;
    if (tipo === 'despesa') {
        tabDespesa.classList.add('active', 'despesa');
        tabReceita.classList.remove('active');
    } else {
        tabReceita.classList.add('active');
        tabDespesa.classList.remove('active', 'despesa');
    }
    atualizarCorValor();
    atualizarImpacto();
}

tabDespesa.addEventListener('click', () => setTransactionType('despesa'));
tabReceita.addEventListener('click', () => setTransactionType('receita'));

// Máscara de dinheiro: o usuário digita só números e eles entram pelos centavos
// Ex.: digitar 1, 5, 0, 9, 0 -> "150,90"
valueInput.addEventListener('input', () => {
    const digitos = valueInput.value.replace(/\D/g, '').replace(/^0+/, '').slice(0, 11);
    valueInput.value = digitos ? formatarNumero(Number(digitos) / 100) : '';
    limparErro('valor');
    atualizarCorValor();
    atualizarImpacto();
});

valueInput.addEventListener('focus', () => {
    if (valueInput.value === '0,00') valueInput.value = '';
});

valueInput.addEventListener('blur', () => {
    if (valueInput.value.trim() === '') valueInput.value = '0,00';
    atualizarCorValor();
});

// Seleção da Forma de Pagamento (clique ou Enter/Espaço no teclado)
function selecionarForma(forma) {
    paymentCards.forEach(c => c.classList.toggle('active', c.dataset.forma === forma));
}

paymentCards.forEach(card => {
    card.addEventListener('click', () => selecionarForma(card.dataset.forma));
    card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            selecionarForma(card.dataset.forma);
        }
    });
});

function formaSelecionada() {
    return document.querySelector('.payment-card.active')?.dataset.forma || 'pix';
}

// Tira o destaque de erro assim que o usuário corrige o campo
descInput.addEventListener('input', () => limparErro('desc'));
categoriaInput.addEventListener('change', () => limparErro('categoria'));
dataInput.addEventListener('change', () => limparErro('data'));

// =====================================================================
// 4. VALIDAÇÃO DOS DADOS
// =====================================================================
const campos = {
    valor:     { wrap: document.getElementById('wrap-valor'),     erro: document.getElementById('erro-valor') },
    desc:      { wrap: document.getElementById('wrap-desc'),      erro: document.getElementById('erro-desc') },
    categoria: { wrap: document.getElementById('wrap-categoria'), erro: document.getElementById('erro-categoria') },
    data:      { wrap: document.getElementById('wrap-data'),      erro: document.getElementById('erro-data') }
};

function marcarErro(nome, mensagem) {
    campos[nome].wrap.classList.add('input-error');
    campos[nome].erro.textContent = mensagem;
}

function limparErro(nome) {
    campos[nome].wrap.classList.remove('input-error');
    campos[nome].erro.textContent = '';
}

function lerFormulario() {
    return {
        descricao: descInput.value.trim().replace(/\s+/g, ' '),
        valor: lerValorDigitado(),
        tipo: tipoAtual,
        categoria: categoriaInput.value,
        data: dataInput.value,
        recorrencia: RECORRENCIAS.includes(recorrenciaInput.value) ? recorrenciaInput.value : 'Nenhuma',
        formaPagamento: formaSelecionada()
    };
}

// Retorna true se estiver tudo certo; se não, marca os campos com erro
function validar(dados) {
    Object.keys(campos).forEach(limparErro);
    let valido = true;

    if (dados.valor <= 0) {
        marcarErro('valor', 'Informe um valor maior que zero.');
        valido = false;
    } else if (dados.valor > VALOR_MAXIMO) {
        marcarErro('valor', 'Valor muito alto.');
        valido = false;
    }

    if (dados.descricao.length < 2) {
        marcarErro('desc', 'A descrição deve ter pelo menos 2 caracteres.');
        valido = false;
    }

    if (!dados.categoria) {
        marcarErro('categoria', 'Selecione uma categoria.');
        valido = false;
    }

    const ano = Number(dados.data.slice(0, 4));
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dados.data) || ano < 2000 || ano > 2100) {
        marcarErro('data', 'Informe uma data válida.');
        valido = false;
    }

    return valido;
}

// =====================================================================
// 5. CREATE e UPDATE — botão "Salvar Transação"
// =====================================================================
form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const dados = lerFormulario();
    if (!validar(dados)) {
        mostrarToast('Confira os campos destacados.', 'erro');
        return;
    }

    setSalvando(true);
    try {
        if (idEmEdicao) {
            // UPDATE: altera o registro existente
            await Banco.atualizar(idEmEdicao, dados);
            mostrarToast('Transação atualizada!');
        } else {
            // CREATE: o IndexedDB gera o id automaticamente
            await Banco.adicionar(dados);
            mostrarToast('Transação salva!');
        }
        limparFormulario();
        await carregarTransacoes(); // relê o banco para atualizar a lista
    } catch (err) {
        mostrarToast(traduzirErro(err), 'erro');
    } finally {
        setSalvando(false);
    }
});

function setSalvando(salvando) {
    btnSave.disabled = salvando;
    if (salvando) {
        btnSaveText.textContent = 'Salvando...';
    } else {
        btnSaveText.textContent = idEmEdicao ? 'Salvar Alterações' : 'Salvar Transação';
    }
}

function limparFormulario() {
    form.reset();
    idEmEdicao = null;
    valueInput.value = '0,00';
    dataInput.value = hojeISO();
    selecionarForma('pix');
    setTransactionType('despesa');
    Object.keys(campos).forEach(limparErro);

    formTitle.textContent = 'Nova Transação';
    btnSaveText.textContent = 'Salvar Transação';
    btnCancel.classList.add('hidden');
    renderizarLista(); // tira o destaque do item que estava em edição
}

btnCancel.addEventListener('click', limparFormulario);

// =====================================================================
// 6. READ — lê todas as transações do banco
// =====================================================================
// É chamada ao abrir a página e depois de cada cadastro, edição ou exclusão.
async function carregarTransacoes() {
    try {
        transacoes = await Banco.listar();
        ordenarTransacoes();
        renderizarLista();
        atualizarImpacto();
    } catch (err) {
        listaStatus.textContent = 'Não foi possível carregar as transações.';
        listaStatus.classList.remove('hidden');
        mostrarToast(traduzirErro(err), 'erro');
    }
}

// Mais recentes primeiro (pela data e, no mesmo dia, pela ordem de cadastro)
function ordenarTransacoes() {
    transacoes.sort((a, b) => b.data.localeCompare(a.data) || b.id - a.id);
}

// =====================================================================
// 7. SEARCH + exibição da lista
// =====================================================================
function transacoesFiltradas() {
    const termo = searchInput.value.trim().toLowerCase();
    return transacoes.filter(t => {
        const passaTipo = filtroTipo === 'todas' || t.tipo === filtroTipo;
        const passaBusca = !termo ||
            t.descricao.toLowerCase().includes(termo) ||
            t.categoria.toLowerCase().includes(termo);
        return passaTipo && passaBusca;
    });
}

function renderizarLista() {
    const visiveis = transacoesFiltradas();

    contador.textContent = `${transacoes.length} ${transacoes.length === 1 ? 'registro' : 'registros'}`;

    if (transacoes.length === 0) {
        listaStatus.textContent = 'Nenhuma transação cadastrada ainda.';
    } else if (visiveis.length === 0) {
        listaStatus.textContent = 'Nenhuma transação encontrada para essa pesquisa.';
    }
    listaStatus.classList.toggle('hidden', visiveis.length > 0);

    lista.innerHTML = visiveis.map(t => {
        const sinal = t.tipo === 'receita' ? '+' : '-';
        const icone = t.tipo === 'receita' ? 'fa-arrow-down' : 'fa-arrow-up';
        const forma = NOMES_FORMA[t.formaPagamento] || '';
        return `
            <li class="transaction-item ${t.id === idEmEdicao ? 'editing' : ''}">
                <div class="tx-icon ${t.tipo}"><i class="fa-solid ${icone}"></i></div>
                <div class="tx-info">
                    <p class="tx-desc">${escaparHTML(t.descricao)}</p>
                    <p class="tx-meta">
                        ${escaparHTML(t.categoria)} • ${formatarData(t.data)} • ${forma}
                        ${t.recorrencia && t.recorrencia !== 'Nenhuma' ? `<span class="tx-badge">${t.recorrencia}</span>` : ''}
                    </p>
                </div>
                <div class="tx-right">
                    <p class="tx-valor ${t.tipo}">${sinal} ${formatarMoeda(t.valor)}</p>
                    <div class="tx-actions">
                        <button type="button" class="tx-btn" data-acao="editar" data-id="${t.id}" title="Editar"><i class="fa-solid fa-pen"></i></button>
                        <button type="button" class="tx-btn danger" data-acao="excluir" data-id="${t.id}" title="Excluir"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </div>
            </li>`;
    }).join('');
}

searchInput.addEventListener('input', renderizarLista);

chips.forEach(chip => {
    chip.addEventListener('click', () => {
        filtroTipo = chip.dataset.filtro;
        chips.forEach(c => c.classList.toggle('active', c === chip));
        renderizarLista();
    });
});

// Um único listener para todos os botões da lista ("event delegation")
lista.addEventListener('click', (e) => {
    const botao = e.target.closest('.tx-btn');
    if (!botao) return;

    const id = Number(botao.dataset.id); // no HTML o id vira texto; no banco é número
    if (botao.dataset.acao === 'editar') editarTransacao(id);
    if (botao.dataset.acao === 'excluir') excluirTransacao(id);
});

// =====================================================================
// 8. UPDATE — carrega a transação no formulário
// =====================================================================
function editarTransacao(id) {
    const t = transacoes.find(item => item.id === id);
    if (!t) return;

    idEmEdicao = id;
    tipoAtual = t.tipo;
    valueInput.value = formatarNumero(t.valor);
    descInput.value = t.descricao;
    categoriaInput.value = t.categoria;
    dataInput.value = t.data;
    recorrenciaInput.value = t.recorrencia || 'Nenhuma';
    selecionarForma(t.formaPagamento);
    setTransactionType(t.tipo);
    Object.keys(campos).forEach(limparErro);

    formTitle.textContent = 'Editar Transação';
    btnSaveText.textContent = 'Salvar Alterações';
    btnCancel.classList.remove('hidden');
    renderizarLista();

    appContent.scrollTo({ top: 0, behavior: 'smooth' });
}

// =====================================================================
// 9. DELETE
// =====================================================================
async function excluirTransacao(id) {
    const t = transacoes.find(item => item.id === id);
    if (!t) return;

    if (!confirm(`Excluir "${t.descricao}" (${formatarMoeda(t.valor)})?`)) return;

    try {
        await Banco.excluir(id);
        if (idEmEdicao === id) limparFormulario();
        await carregarTransacoes();
        mostrarToast('Transação excluída.');
    } catch (err) {
        mostrarToast(traduzirErro(err), 'erro');
    }
}

// =====================================================================
// 10. IMPACTO NO SALDO (calculado com os dados reais do banco)
// =====================================================================
function calcularSaldo() {
    return transacoes.reduce((saldo, t) => t.tipo === 'receita' ? saldo + t.valor : saldo - t.valor, 0);
}

function atualizarImpacto() {
    let saldoBase = calcularSaldo();

    // Na edição, desconta o valor antigo para não contar a transação duas vezes
    if (idEmEdicao) {
        const original = transacoes.find(t => t.id === idEmEdicao);
        if (original) {
            saldoBase += original.tipo === 'receita' ? -original.valor : original.valor;
        }
    }

    const valor = lerValorDigitado();
    const saldoFinal = tipoAtual === 'receita' ? saldoBase + valor : saldoBase - valor;

    impactValue.textContent = formatarMoeda(saldoFinal);
    impactValue.style.color = saldoFinal < 0 ? COR_DESPESA : '';
    impactSub.textContent = `Saldo atual: ${formatarMoeda(calcularSaldo())}`;
}

// =====================================================================
// 11. AVISO FLUTUANTE (toast)
// =====================================================================
let timerToast = null;

function mostrarToast(texto, tipo = 'sucesso') {
    toastEl.textContent = texto;
    toastEl.className = `toast show ${tipo}`;
    clearTimeout(timerToast);
    timerToast = setTimeout(() => toastEl.classList.remove('show'), 3000);
}

// ====== ESTADO INICIAL ======
dataInput.value = hojeISO();
atualizarCorValor();
carregarTransacoes(); // lê o banco assim que a página abre
