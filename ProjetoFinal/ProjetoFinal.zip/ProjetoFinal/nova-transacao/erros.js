// =====================================================================
// TRATAMENTO DE ERROS
// ---------------------------------------------------------------------
// O IndexedDB devolve erros com um "name" em inglês (ex.: QuotaExceededError).
// Esta função converte esses nomes em mensagens claras em português
// para mostrar ao usuário. O erro original continua no console (F12).
// =====================================================================

const MENSAGENS = {
    'SemIndexedDB': 'Seu navegador não suporta banco de dados local. Use Chrome, Edge ou Firefox atualizados.',
    'BancoBloqueado': 'O banco está aberto em outra aba. Feche as outras abas do FechaConta e recarregue.',
    'QuotaExceededError': 'Sem espaço para salvar. Libere espaço no navegador e tente de novo.',
    'NotFoundError': 'Registro não encontrado (talvez já tenha sido excluído).',
    'ConstraintError': 'Já existe um registro com esse identificador.',
    'DataError': 'Algum dado enviado é inválido.',
    'InvalidStateError': 'O banco foi fechado. Recarregue a página.',
    'VersionError': 'A versão do banco mudou. Recarregue a página.',
    'SecurityError': 'O navegador bloqueou o banco local (modo anônimo ou permissões). Tente numa janela normal.',
    'AbortError': 'A operação foi cancelada. Tente novamente.'
};

function traduzirErro(erro) {
    console.error('[FechaConta]', erro);
    return MENSAGENS[erro?.name] || 'Ocorreu um erro inesperado. Tente novamente.';
}
