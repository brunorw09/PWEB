// =====================================================================
// BANCO DE DADOS LOCAL — IndexedDB
// ---------------------------------------------------------------------
// O IndexedDB é um banco de dados que já vem no navegador. Ele guarda
// objetos em "object stores" (parecido com tabelas), com chave primária,
// índices e transações. Todas as operações são assíncronas, então aqui
// cada uma é embrulhada numa Promise para poder usar async/await.
//
// Banco: FechaContaDB  >  object store: transacoes
//   id             number   gerado automaticamente (autoIncrement)
//   descricao      string   "Mercado Central"
//   valor          number   150.9
//   tipo           string   "despesa" | "receita"
//   categoria      string   "Alimentação"
//   data           string   "2026-11-06"  (formato AAAA-MM-DD)
//   recorrencia    string   "Nenhuma" | "Diário" | "Semanal" | "Mensal" | "Anual"
//   formaPagamento string   "cartao" | "pix" | "dinheiro"
//   criadoEm       string   data/hora de criação (ISO)
//   atualizadoEm   string   data/hora da última edição (ISO)
//
// Para ver os dados: F12 > Application (Aplicativo) > IndexedDB > FechaContaDB
// =====================================================================

const NOME_BANCO = 'FechaContaDB';
const VERSAO_BANCO = 1;
const TABELA = 'transacoes';

let conexao = null; // a conexão é aberta uma vez e reaproveitada

function abrirBanco() {
    if (conexao) return Promise.resolve(conexao);

    return new Promise((resolver, rejeitar) => {
        if (!window.indexedDB) {
            rejeitar({ name: 'SemIndexedDB' });
            return;
        }

        const pedido = indexedDB.open(NOME_BANCO, VERSAO_BANCO);

        // Roda só na primeira vez (ou quando a versão muda): cria a estrutura
        pedido.onupgradeneeded = () => {
            const banco = pedido.result;
            if (!banco.objectStoreNames.contains(TABELA)) {
                const tabela = banco.createObjectStore(TABELA, { keyPath: 'id', autoIncrement: true });
                tabela.createIndex('data', 'data');
                tabela.createIndex('tipo', 'tipo');
            }
        };

        pedido.onsuccess = () => {
            conexao = pedido.result;
            resolver(conexao);
        };
        pedido.onerror = () => rejeitar(pedido.error);
        pedido.onblocked = () => rejeitar({ name: 'BancoBloqueado' });
    });
}

// Executa uma operação dentro de uma transação e devolve o resultado.
// modo: 'readonly' para ler | 'readwrite' para gravar/excluir
async function executar(modo, operacao) {
    const banco = await abrirBanco();

    return new Promise((resolver, rejeitar) => {
        const transacao = banco.transaction(TABELA, modo);
        const pedido = operacao(transacao.objectStore(TABELA));

        // Só considera concluído quando a transação inteira terminou
        transacao.oncomplete = () => resolver(pedido.result);
        transacao.onerror = () => rejeitar(transacao.error);
        transacao.onabort = () => rejeitar(transacao.error || { name: 'AbortError' });
    });
}

// ====== OPERAÇÕES DO CRUD ======
const Banco = {
    // READ: todas as transações
    listar() {
        return executar('readonly', tabela => tabela.getAll());
    },

    // READ: uma transação pelo id
    buscar(id) {
        return executar('readonly', tabela => tabela.get(id));
    },

    // CREATE: devolve o id gerado
    adicionar(transacao) {
        return executar('readwrite', tabela => tabela.add({ ...transacao, criadoEm: new Date().toISOString() }));
    },

    // UPDATE: put() substitui o registro que tem o mesmo id
    async atualizar(id, dados) {
        const atual = await Banco.buscar(id);
        if (!atual) throw { name: 'NotFoundError' };
        return executar('readwrite', tabela => tabela.put({ ...atual, ...dados, id, atualizadoEm: new Date().toISOString() }));
    },

    // DELETE
    excluir(id) {
        return executar('readwrite', tabela => tabela.delete(id));
    }
};
